<?php require ('inc/header.php') ?>

<link rel="stylesheet" type="text/css" href="css/inner.css">




<section class="stall-page all-sec-padding">
    <div class="container">
        <div class="innerpage-title title-wrapper">
            <h2>EXHIBITION HALL</h2>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="top-stall-wrapper">
                    <a href="detail.php" class="stall-main-image"><img src="images/stall_platimum-sponsor.jpg" alt="stall"></a>
                    <a href="detail.php" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <div class="top-stall-wrapper other-stall">
                    <a href="#" class="stall-main-image"><img src="images/stall_gold-sponsor.jpg" alt="stall"></a>
                    <a href="#" class="btn stall-btn">Enter Stall</a>
                </div>
            </div>
        </div>
    </div>
</section>





<?php require ('inc/footer.php') ?>