
    <!-- footer section starts -->

    <footer class="all-sec-padding">
        <div class="container">
            <ul class="footer-menu">
                <li><a href="stall.php">Exhibition Hall</a></li>
                <li><a href="exhibitors.php">Exhibitors</a></li>
                <li><a href="scholarship.php">Scholarships</a></li>
                <li><a type="button" data-toggle="modal" data-target="#myModal">Guide Me</a></li>
                <li><a href="log-res.php">Log In</a></li>
                <li><a href="log-res.php">Register</a></li>
            </ul>
            <ul class="footer-media">
                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            </ul>
        </div>
    </footer>


    
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/bootstrap-select.js"></script>
<script src="js/custom.js"></script>

</body>
</html>